<section class="content container-fluid">
<div class="row">
        <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-light-blue">
        <div class="inner">
            <h3>2</h3>
            <p>Hadir</p>
        </div>
        <div class="icon">
            <i class="fa fa-graduation-cap"></i>
        </div>
        <a href="http://localhost/istren2/jurusan" class="small-box-footer">
            More info <i class="fa fa-arrow-circle-right"></i>
        </a>
        </div>
    </div>
        <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-olive">
        <div class="inner">
            <h3>5</h3>
            <p>Sakit</p>
        </div>
        <div class="icon">
            <i class="fa fa-building-o"></i>
        </div>
        <a href="http://localhost/istren2/kelas" class="small-box-footer">
            More info <i class="fa fa-arrow-circle-right"></i>
        </a>
        </div>
    </div>
        <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-yellow-active">
        <div class="inner">
            <h3>2</h3>
            <p>Ijin</p>
        </div>
        <div class="icon">
            <i class="fa fa-user-secret"></i>
        </div>
        <a href="http://localhost/istren2/dosen" class="small-box-footer">
            More info <i class="fa fa-arrow-circle-right"></i>
        </a>
        </div>
    </div>
        <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-red">
        <div class="inner">
            <h3>1</h3>
            <p>Cuti</p>
        </div>
        <div class="icon">
            <i class="fa fa-user"></i>
        </div>
        <a href="http://localhost/istren2/mahasiswa" class="small-box-footer">
            More info <i class="fa fa-arrow-circle-right"></i>
        </a>
        </div>
    </div>
    </div>

			</section>