<?php
defined('BASEPATH') OR exit('No direct script access allowed');



class LaporanAbsen extends MX_Controller {

  public function __construct()
  {
    parent::__construct();
	$this->load->model('all/M_departemen');
	$this->load->model('M_karyawan');
	$this->load->model('M_laporanabsen');
	$this->load->model('all/M_combo');
  }

  public function index()
  {

	if($this->session->userdata('status') != TRUE){
		redirect(base_url("all/login"));
  	}

		$akseslembaga = $this->session->userdata('akseslembaga');
		$idlembaga = $this->session->userdata('idlembaga');
		$aksesdepartemen = $this->session->userdata('aksesdepartemen');
		$idepartemen = $this->session->userdata('iddepartemen');

		$tglawal = date('d-m-Y');
		$tglakhir = date('d-m-Y');
		$idkaryawan = $this->input->post('idkaryawan');

		//Jika akses antar lemmbaga 
		if ($akseslembaga == 'Y'){
		$idlembaga = 'all';
		}

		if ($aksesdepartemen == 'Y'){
		$idepartmen = 'all';
		}

		$data['combolembaga'] = $this->M_combo->combolembaga($idlembaga);
		$data['datadepartemen'] = $this->M_departemen->tampil_departemen($idlembaga);
		$data['combounitkerja'] = $this->M_combo->combounitkerja();

		$data['rekapabsen'] = $this->M_laporanabsen->rekap_absen_karyawan($idkaryawan,$tglawal,$tglakhir);


		$data['header'] = 'layout/header';
		$data['topbar'] = 'layout/topbar';
		$data['sidebar'] = 'layout/sidebar';
		$data['content'] = 'laporan/v_rekapabsenkaryawan';
		$data['js'] = 'layout/js';
		$data['jscontent'] = 'laporan/jscontent';
		$data['footer'] = 'layout/footer';
		$this->load->view('layout/main', $data);
	}

	public function rekap_absensi_karyawan()
	{
			if($this->session->userdata('status') != TRUE){
					redirect(base_url("all/login"));
			}
			
			$akseslembaga = $this->session->userdata('akseslembaga');
			$idlembaga = $this->session->userdata('idlembaga');
			$aksesdepartemen = $this->session->userdata('aksesdepartemen');
			$idepartemen = $this->session->userdata('iddepartemen');

			$tglawal = $this->input->post('tglawal');
			$tglakhir = $this->input->post('tglakhir');
			$idkaryawan = $this->input->post('idkaryawan');
			
			
			//Jika akses antar lemmbaga 
			if ($akseslembaga == 'Y'){
				$idlembaga = 'all';
			}

			if ($aksesdepartemen == 'Y'){
				$idepartmen = 'all';
			}
			
			$data['combolembaga'] = $this->M_combo->combolembaga($idlembaga);
			$data['datadepartemen'] = $this->M_departemen->tampil_departemen($idlembaga);
			$data['combounitkerja'] = $this->M_combo->combounitkerja();
			$data['rekapabsen'] = $this->M_laporanabsen->rekap_absen_karyawan($idkaryawan,$tglawal,$tglakhir);
			
			$data['header'] = 'layout/header';
			$data['topbar'] = 'layout/topbar';
			$data['sidebar'] = 'layout/sidebar';
			$data['content'] = 'laporan/v_rekapabsenkaryawan';
			$data['js'] = 'layout/js';
			$data['jscontent'] = 'laporan/jscontent';
			$data['footer'] = 'layout/footer';
			$this->load->view('layout/main', $data);
	}

	public function exp_rekap_absensi_karyawan($idkaryawan,$tglawal,$tglakhir)
	{
		if($this->session->userdata('status') != "login"){
			redirect(base_url("all/login"));
		}
		

	
		$data['rekapabsen'] = $this->M_laporanabsen->rekap_absen_karyawan($idkaryawan,$tglawal,$tglakhir);

		
		$data['judul'] = 'Laporan Presensi Karyawan';
		
		$this->load->view('kepegawaian/laporan/v_exp_rekap_absen_karyawan',$data);
	}

	public function exp_rekap_absensi_unitkerja($idunitkerja,$tglawal,$tglakhir)
	{
		if($this->session->userdata('status') != "login"){
			redirect(base_url("all/login"));
		}
		

	
		$data['rekapabsen'] = $this->M_laporanabsen->rekap_absen_unitkerja($idunitkerja,$tglawal,$tglakhir);

		
		$data['judul'] = 'Laporan Presensi Karyawan';
		
		$this->load->view('kepegawaian/laporan/v_exp_rekap_absen_unitkerja',$data);
	}


	/*public function exp_rekap_absen_karyawan1(){
			// Load plugin PHPExcel nya
			include APPPATH.'third_party/PHPExcel/PHPExcel.php';
			
			// Panggil class PHPExcel nya
			$excel = new PHPExcel();
			// Settingan awal fil excel
			$excel->getProperties()->setCreator('My Notes Code')
						 ->setLastModifiedBy('My Notes Code')
						 ->setTitle("Data Siswa")
						 ->setSubject("Siswa")
						 ->setDescription("Laporan Semua Data Siswa")
						 ->setKeywords("Data Siswa");
			// Buat sebuah variabel untuk menampung pengaturan style dari header tabel
			$style_col = array(
			  'font' => array('bold' => true), // Set font nya jadi bold
			  'alignment' => array(
				'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
				'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
			  ),
			  'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			  )
			);
			// Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
			$style_row = array(
			  'alignment' => array(
				'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
			  ),
			  'borders' => array(
				'top' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right' => array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom' => array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left' => array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			  )
			);
			$excel->setActiveSheetIndex(0)->setCellValue('A1', "DATA SISWA"); // Set kolom A1 dengan tulisan "DATA SISWA"
			$excel->getActiveSheet()->mergeCells('A1:E1'); // Set Merge Cell pada kolom A1 sampai E1
			$excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE); // Set bold kolom A1
			$excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15); // Set font size 15 untuk kolom A1
			$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // Set text center untuk kolom A1
			// Buat header tabel nya pada baris ke 3
			$excel->setActiveSheetIndex(0)->setCellValue('A3', "NO"); // Set kolom A3 dengan tulisan "NO"
			$excel->setActiveSheetIndex(0)->setCellValue('B3', "NIS"); // Set kolom B3 dengan tulisan "NIS"
			$excel->setActiveSheetIndex(0)->setCellValue('C3', "NAMA"); // Set kolom C3 dengan tulisan "NAMA"
			$excel->setActiveSheetIndex(0)->setCellValue('D3', "JENIS KELAMIN"); // Set kolom D3 dengan tulisan "JENIS KELAMIN"
			$excel->setActiveSheetIndex(0)->setCellValue('E3', "ALAMAT"); // Set kolom E3 dengan tulisan "ALAMAT"
			// Apply style header yang telah kita buat tadi ke masing-masing kolom header
			$excel->getActiveSheet()->getStyle('A3')->applyFromArray($style_col);
			$excel->getActiveSheet()->getStyle('B3')->applyFromArray($style_col);
			$excel->getActiveSheet()->getStyle('C3')->applyFromArray($style_col);
			$excel->getActiveSheet()->getStyle('D3')->applyFromArray($style_col);
			$excel->getActiveSheet()->getStyle('E3')->applyFromArray($style_col);
			// Panggil function view yang ada di SiswaModel untuk menampilkan semua data siswanya
			//$siswa = $this->SiswaModel->view();
			$no = 1; // Untuk penomoran tabel, di awal set dengan 1
			$numrow = 4; // Set baris pertama untuk isi tabel adalah baris ke 4
			
			// Set width kolom
			$excel->getActiveSheet()->getColumnDimension('A')->setWidth(5); // Set width kolom A
			$excel->getActiveSheet()->getColumnDimension('B')->setWidth(15); // Set width kolom B
			$excel->getActiveSheet()->getColumnDimension('C')->setWidth(25); // Set width kolom C
			$excel->getActiveSheet()->getColumnDimension('D')->setWidth(20); // Set width kolom D
			$excel->getActiveSheet()->getColumnDimension('E')->setWidth(30); // Set width kolom E
			
			// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
			$excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
			// Set orientasi kertas jadi LANDSCAPE
			$excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
			// Set judul file excel nya
			$excel->getActiveSheet(0)->setTitle("Laporan Data Siswa");
			$excel->setActiveSheetIndex(0);
			// Proses file excel
			header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
			header('Content-Disposition: attachment; filename="Data Siswa.xlsx"'); // Set nama file excel nya
			header('Cache-Control: max-age=0');
			$write = PHPExcel_IOFactory::createWriter($excel, 'Excel2007');
			$write->save('php://output');
		
		
		
	}

	public function exp_rekap_absen_karyawan()
	{
	
		
				// Setup Excel Header masing-masing Sheets
				$header_mhs = ['Nama Mahasiswa', 'Alamat', 'Nilai'];
				$header_dsn = ['Nama Dosen', 'Alamat', 'Gaji'];
				$header_kry = ['Nama Karyawan', 'Alamat', 'Gaji'];
		
				// simulate data dari database, kalau data kamu dari DB, silahkan
				// bentuk menjadi seperti ini
		
				$data_mhs = [
					['Agus', 'Jl. Jaksa Jakarta', 90],
					['Budy', 'Jl. Palmerah Jakarta', 70],
					['Cecep', 'Jl. Sukacita Bandung', 77],
				];
		
				$data_dsn = [
					['Dr. Sutomo Ph.D', 'Jl. Patimura Jakarta', 7500000],
					['Ir. Dedot Pekok', 'Jl. Cilincing Jakarta', 5600000],
					['Sontoloyo S.kom M.kom', 'Jl. senayan Bandung', 4700000],
				];
		
				$data_kry = [
					['Nur soleh', 'Jl. bebas polusi Jakarta', 3200000],
					['Denis', 'Jl. kovyor Belitung', 2600000],
					['Sutarni', 'Jl. sudirman Jakarta', 2700000],
				];
		
				// setup Spout Excel Writer, set tipenya xlsx
				$writer = WriterFactory::create(Type::XLSX);
				// download to browser
				$writer->openToBrowser('Contoh-Data-Saja.xlsx');
				// set style untuk header
				$headerStyle = (new StyleBuilder())
					   ->setFontBold()
					   ->build();
		
		
				// write ke Sheet pertama
				$writer->getCurrentSheet()->setName('MAHASISWA');
				// header Sheet pertama
				$writer->addRowWithStyle($header_mhs, $headerStyle);
				// data Sheet pertama
				$writer->addRows($data_mhs);
		
				// write ke Sheet kedua
				$writer->addNewSheetAndMakeItCurrent()->setName('DOSEN');
				// header Sheet kedua
				$writer->addRowWithStyle($header_dsn, $headerStyle);
				// data Sheet kedua
				$writer->addRows($data_dsn);
		
				// write ke Sheet ketiga
				$writer->addNewSheetAndMakeItCurrent()->setName('KAYRAWAN');
				// header Sheet ketiga
				$writer->addRowWithStyle($header_kry, $headerStyle);
				// data Sheet ketiga
				$writer->addRows($data_kry);
		
		
				// close writter
				$writer->close();
		
		
				
	}*/
 
 
   //tambah data
   public function tambah_departemen()
  {
	
	if($this->session->userdata('status') != TRUE)
	{
        redirect(base_url("all/login"));
	}
	
$this->form_validation->set_rules('namadepartemen','Nama Departemen','required|trim');

if ($this->form_validation->run() == TRUE){
	
	$idlembaga 			= $this->input->post('idlembaga');
	$namadepartemen		= $this->input->post('namadepartemen');
	$ketdepartemen		= $this->input->post('ketdepartemen');
	$kepaladepartemen	= $this->input->post('kepaladepartemen');
	$alamatdepartemen	= $this->input->post('alamatdepartemen');
	$notlp1				= $this->input->post('notlp1');
	$notlp2				= $this->input->post('notlp2');
	$nofax				= $this->input->post('nofax');
	$email				= $this->input->post('email');
	$website			= $this->input->post('website');
	$logo				= $this->input->post('logo');
	
	$config['upload_path'] = './storage/photo/lembaga/';
	$config['allowed_types'] = 'jpeg|gif|jpg|png';
	$config['overwrite'] = TRUE ;
	$config['encrypt_name'] =TRUE;
	//$config['file_name'] = "logo-".$iddepartemen ;
	$this->load->library('upload', $config);
	

	if (!empty($_FILES['logo']['name']))
	{
		if ($this->upload->do_upload('logo')){
			$gbr = $this->upload->data();
			//Compress Image
			$config['image_library']='gd2';
			$config['source_image']='./storage/photo/departemen/'.$gbr['file_name'];
			$config['create_thumb']= FALSE;
			$config['maintain_ratio']= FALSE;
			$config['quality']= '50%';
			$config['width']= 150;
			$config['height']=150;
			$config['new_image']= './storage/photo/departemen/'.$gbr['file_name'];
			$this->load->library('image_lib', $config);
			$this->image_lib->resize();
			$logo=$gbr['file_name'];
		}		
		else
		{
			echo $this->session->set_flashdata('msg','error');
			$url = base_url('all/departemen'.'?'.uniqid());
			redirect($url,'refresh');
		}	
	}
	
	$datadepartemen = array(
		'id_lembaga'			=> $idlembaga,
		'nama_departemen'		=> str_replace("'","`",$namadepartemen),                 
		'keterangan_departemen' => str_replace( "'","`",$ketdepartemen),                
		'kepala_departemen'     => $kepaladepartemen,                 
		'alamat_departemen'     => str_replace("'","`",$alamatdepartemen),                 
		'notlp_departemen'      => $notlp1,                 
		'notlp_departemen2'		=> $notlp2,                  
		'fax_departemen'        => $nofax,                 
		'email_departemen'      => $email,                 
		'web_departemen'        => $website,                 
		'icon_departemen'		=> $logo
	);

    $hasil = $this->M_departemen->tambah_departemen($datadepartemen);
	
    if($hasil==TRUE){
		echo $this->session->set_flashdata('msg','success');
    }else{
		echo $this->session->set_flashdata('msg','error');
    }
	  $url = base_url('all/departemen'.'?'.uniqid());
	  redirect($url,'refresh');
	}
	else
	{
			

	}

}
  
   //ubah data  
   public function ubah_departemen()
  {
  
	if($this->session->userdata('status') != TRUE){
        redirect(base_url("all/login"));
	}
	
	$idlembaga 			= $this->input->post('idlembaga');
	$iddepartemen		= $this->input->post('iddepartemen');
	$namadepartemen 	= $this->input->post('namadepartemen');
	$namalembaga		= $this->input->post('namalembaga');
	$ketdepartemen		= $this->input->post('ketdepartemen');
	$kepaladepartemen	= $this->input->post('kepaladepartemen');
	$alamatdepartemen	= $this->input->post('alamatdepartemen');
	$notlp1				= $this->input->post('notlp1');
	$notlp2				= $this->input->post('notlp2');
	$nofax				= $this->input->post('nofax');
	$email				= $this->input->post('email');
	$website			= $this->input->post('website');
	$logo				= $this->input->post('logo');
	
	$config['upload_path'] = './storage/photo/departemen/';
	$config['allowed_types'] = 'jpeg|gif|jpg|png';
	$config['overwrite'] = TRUE ;
	$config['encrypt_name'] =TRUE;
	$this->load->library('upload', $config);
	
	

	if (!empty($_FILES['logo']['name']))
	{
		if ($this->upload->do_upload('logo')){
			$gbr = $this->upload->data();
			//Compress Image
			$config['image_library']='gd2';
			$config['source_image']='./storage/photo/departemen/'.$gbr['file_name'];
			$config['create_thumb']= FALSE;
			$config['maintain_ratio']= FALSE;
			$config['quality']= '50%';
			$config['width']= 150;
			$config['height']=150;
			$config['new_image']= './storage/photo/departemen/'.$gbr['file_name'];
			$this->load->library('image_lib', $config);
			$this->image_lib->resize();
			$logo=$gbr['file_name'];
		}		
		else
		{
			echo $this->session->set_flashdata('msg','error');
			$url = base_url('all/departemen'.'?'.uniqid());
			redirect($url,'refresh');
		}	
	}
	
	$datadepartemen = array(
		'nama_departemen'		=> str_replace("'","`",$namadepartemen),                 
		'keterangan_departemen' => str_replace("'","`",$namadepartemen),               
		'kepala_departemen'     => $kepaladepartemen,                 
		'alamat_departemen'     => str_replace("'","`",$namadepartemen),                 
		'notlp_departemen'      => $notlp1,                 
		'notlp_departemen2'		=> $notlp2,                  
		'fax_departemen'        => $nofax,                 
		'email_departemen'      => $email,                 
		'web_departemen'        => $website,                 
		'icon_departemen'		=> $logo
	);

    $hasil = $this->M_departemen->ubah_departemen($iddepartemen,$datadepartemen);
	
    if($hasil==TRUE){
		echo $this->session->set_flashdata('msg','success');
    }else{
		echo $this->session->set_flashdata('msg','error');
    }
	  $url = base_url('all/departemen'.'?'.uniqid());
	  redirect($url,'refresh');
} 
	  
	public function hapus_departemen()
  {
  
	if($this->session->userdata('status') != TRUE){
        redirect(base_url("all/login"));
	}
	
    $id				=	$this->input->post('iddepartemen');
	$icondepartemen	=	$this->input->post('icondepartemen');
	 
    $hasil = $this->M_departemen->hapus_departemen($id);

    if($hasil==TRUE){
	  unlink('./storage/photo/lembaga/'.$icondepartemen);	
      echo $this->session->set_flashdata('msg','success');
    }else{
      echo $this->session->set_flashdata('msg','error');
    }
     $url = base_url('all/departemen'.'?'.uniqid());
			redirect($url,'refresh');
  }
	
}
  
	

