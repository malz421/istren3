

<!--load select2-->
<script>
  $(function () {
    $(".select2").select2();
  });
</script>

<script>
    $('#tglawal').datepicker({
      autoclose: true
    });
	$('#tglakhir').datepicker({
      autoclose: true
    });

</script>

<script type="text/javascript">
$(document).ready(function() {
    var table = $('#example2').dataTable({
					scrollX : true,
					paging: false,
	  				ordering: true,
                    scrollCollapse : true
                });
});
</script>



<!--pop message box -->
<?php if ($this->session->flashdata('msg') == 'success'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Success',
				text: "Data Berhasil Disimpan.",
				showHideTransition: 'slide',
				icon: 'success',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#7EC857'
			});
	</script>
<?php elseif ($this->session->flashdata('msg') == 'info'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Info',
				text: "Data berhasil di update",
				showHideTransition: 'slide',
				icon: 'info',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#00C9E6'
			});
	</script>
<?php elseif ($this->session->flashdata('msg') == 'success-hapus'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Success',
				text: "Data Berhasil dihapus.",
				showHideTransition: 'slide',
				icon: 'success',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#7EC857'
			});
	</script>
<?php elseif ($this->session->flashdata('msg') == 'error'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Error',
				text: "Data Gagal Disimpan.",
				showHideTransition: 'slide',
				icon: 'danger',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#FF4859'
			});
	</script>
<?php else: ?>
<?php endif;?>


<!--COMBO-->
<script type="text/javascript">

   $(document).ready(function(){
	   ajaxcsrf();
	   	var idlembaga = $('#idlembaga').val();
		var idunitkerja = $("#idunitkerja").val();
		var tglawal = $("#tglawal").val();
		var tglakhir = $("#tglakhir").val();
		var idkaryawan = $('#idkaryawan').val();

		$('#idlembaga').change(function(e){

			var idlembaga = $('#idlembaga').val();
			var idunitkerja = $("#idunitkerja").val();
			$.ajax({
			    type: 'POST',
				url: '<?php echo base_url('kepegawaian/karyawan/tampil_combo_karyawan') ?>',
			    data: { 'idlembaga' : idlembaga,'idunitkerja' : idunitkerja},
				success: function(data){
				if(data.length > 0){
					$("#idkaryawan").html(data);
			   }
			   else
			   {
				$('#idkaryawan').html("<option><---Pilih Karyawan---></option>");
			   }
			  }
			})
		})


			$.ajax({
			    type: 'POST',
				url: '<?php echo base_url('kepegawaian/karyawan/tampil_combo_karyawan') ?>',
			    data: { 'idlembaga' : idlembaga,'idunitkerja' : idunitkerja},
				success: function(data){
				if(data.length > 0){
					$("#idkaryawan").html(data);
			   }
			   else
			   {
				$('#idkaryawan').html("<option><---Pilih Karyawan---></option>");
			   }
			  }
			})

			$("#exprekapabsenkaryawan").attr("href", "<?php echo base_url() . 'kepegawaian/laporanabsen/exp_rekap_absensi_karyawan/'; ?>"+idkaryawan+"/"+tglawal+"/"+tglakhir);

			$('#idunitkerja').change(function(e){

			var idlembaga = $('#idlembaga').val();
			var idunitkerja = $("#idunitkerja").val();
			ajaxcsrf();

			$.ajax({
			    type: 'POST',
				url: '<?php echo base_url('kepegawaian/karyawan/tampil_combo_karyawan') ?>',
			    data: { 'idlembaga' : idlembaga,'idunitkerja' : idunitkerja},
				success: function(data){
				if(data.length > 0){
					$("#idkaryawan").html(data);
			   }
			   else
			   {
				$('#idkaryawan').html("<option><---Pilih Karyawan---></option>");
			   }
			  }
			})
		})


		$('#idkaryawan').change(function(e){

		var idkaryawan = $('#idkaryawan').val();
		var tglawal = $("#tglawal").val();
		var tglakhir = $("#tglakhir").val();

        $("#exprekapabsenkaryawan").attr("href", "<?php echo base_url() . 'kepegawaian/laporanabsen/exp_rekap_absensi_karyawan/'; ?>"+idkaryawan+"/"+tglawal+"/"+tglakhir);
		});



		$('#tglawal').change( function(){


		var idkaryawan = $('#idkaryawan').val();
		var tglawal = $("#tglawal").val();
		var tglakhir = $("#tglakhir").val();

		$("#exprekapabsenkaryawan").attr("href", "<?php echo base_url() . 'kepegawaian/laporanabsen/exp_rekap_absensi_karyawan/'; ?>"+idkaryawan+"/"+tglawal+"/"+tglakhir);
		});

		$('#tglakhir').change( function(){


		var idkaryawan = $('#idkaryawan').val();
		var tglawal = $("#tglawal").val();
		var tglakhir = $("#tglakhir").val();

		$("#exprekapabsenkaryawan").attr("href", "<?php echo base_url() . 'kepegawaian/laporanabsen/exp_rekap_absensi_karyawan/'; ?>"+idkaryawan+"/"+tglawal+"/"+tglakhir);
		});




	})
</script>


<!-- Load Gambar -->
<script>
	function readURL() {

    var oFReader = new FileReader();
     oFReader.readAsDataURL(document.getElementById("image").files[0]);

    oFReader.onload = function(oFREvent) {
      document.getElementById("blah").src = oFREvent.target.result;
    };
  };
</script>

<!--Format Tanggal -->
<?php
function rubah_tanggal($date)
{
    $BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");

    $tahun = substr($date, 0, 4);
    $bulan = substr($date, 5, 2);
    $tgl = substr($date, 8, 2);
    //result = $tgl . "-" . $BulanIndo[(int)$bulan-1]. "-". $tahun;
    $result = $tgl . "-" . $bulan . "-" . $tahun;
    return ($result);
}

?>



