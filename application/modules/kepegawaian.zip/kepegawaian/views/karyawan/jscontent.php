

<!--load select2-->
<script>
  $(function () {
    $(".select2").select2();
  });
</script>

<script>
    $('#datepicker').datepicker({
      autoclose: true
    });
	$('#datepicker2').datepicker({
      autoclose: true
    });

	$('#datepickeluarga').datepicker({
      autoclose: true
    });
</script>

<!--load datatables -->
<!--<script>
  $(function () {
    $('#karyawan').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true
    });
  });
</script>-->


<!--<script type="text/javascript">
$(function(){
	$('.formtambahkeluarga').submit(function(event){
		event.preventDefault();
		var form_data = {
				idkel: $('#idkel').val(),
				nikkel : $('#nikkel').val(),
				namakel: $('#namakel').val()
    		};
		$.ajax({
				type: 'POST',
				url: '<?php echo base_url() . 'kepegawaian/karyawan/simpan_keluarga'; ?>',
				data: form_data,
				dataType: 'JSON',
				success: function(results){
					if(something not as you expected){
					$('.error_msg').html('error msg');
					return false;
					}
				}
		});
	});
});
</script>-->

<!--pop message box -->
<?php if ($this->session->flashdata('msg') == 'success'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Success',
				text: "Data Berhasil Disimpan.",
				showHideTransition: 'slide',
				icon: 'success',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#7EC857'
			});
	</script>
<?php elseif ($this->session->flashdata('msg') == 'info'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Info',
				text: "Data berhasil di update",
				showHideTransition: 'slide',
				icon: 'info',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#00C9E6'
			});
	</script>
<?php elseif ($this->session->flashdata('msg') == 'success-hapus'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Success',
				text: "Data Berhasil dihapus.",
				showHideTransition: 'slide',
				icon: 'success',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#7EC857'
			});
	</script>
<?php elseif ($this->session->flashdata('msg') == 'error'): ?>
	<script type="text/javascript">
			$.toast({
				heading: 'Error',
				text: "Data Gagal Disimpan.",
				showHideTransition: 'slide',
				icon: 'danger',
				hideAfter: false,
				position: 'bottom-right',
				bgColor: '#FF4859'
			});
	</script>
<?php else: ?>
<?php endif;?>

<script type="text/javascript">
var table;
$(document).ready(function() {
  ajaxcsrf();

  table = $("#karyawan").DataTable({
    initComplete: function() {
      var api = this.api();
      $("#karyawan_filter input")
        .off(".DT")
        .on("keyup.DT", function(e) {
          api.search(this.value).draw();
        });
    },
    dom:
      "<'row'<'col-sm-3'l><'col-sm-6 text-center'B><'col-sm-3'f>>" +
      "<'row'<'col-sm-12'tr>>" +
      "<'row'<'col-sm-5'i><'col-sm-7'p>>",
    buttons: [
      {
        extend: "copy",
        exportOptions: { columns: [1,2,3] }
      },
      {
        extend: "print",
        exportOptions: { columns: [1,2,3] }
      },
      {
        extend: "excel",
        exportOptions: { columns: [1,2,3] }
      },
      {
        extend: "pdf",
        exportOptions: { columns: [1,2,3] }
      }
    ],
    oLanguage: {
      sProcessing: "loading..."
    },
    processing: true,
    serverSide: true,
    ajax: {
      url: base_url + "kepegawaian/Karyawan/data",
      type: "POST"
    },
    columns: [
      {
        data: "id_karyawan",
        orderable: false,
        searchable: false
      },
	  {
        data: "id_karyawan",
        orderable: false,
        searchable: false
      },
      {data: "photo_profile",
        "searchable": false,
        "orderable":false,
        "render": function(data, type, row, meta)
        {

             return `<img src="${base_url}storage/photo/karyawan/avatar.jpg" style='align:center' height="60px" width="60px"">`
        }
      },
      { data: "nip_karyawan"},
      { data: "nik_karyawan",
        "render": function(data, type, row, meta) {
          if ( data == null){
             return ``
          }
          else
          {
            return  `${data}`
          }
        }
      },
      { data: "nama_karyawan"},
      { data: "nama_lembaga"},
       { data: "unit_kerja",
        "render": function(data, type, row, meta) {
          if ( data == null){
             return ``
          }
          else
          {
            return  `${data}`
          }
        }
      },
      { data: "jenis_kelamin",
        "render": function(data, type, row, meta) {
          if ( data =='P'){
             return `Perempuan`
          }
          else
          {
            return  `Laki-laki`
          }
        }
      },
      { data: "id_karyawan",
        render: function(data, type, row, meta) {
          return `<div class="text-center">
                                <a href="${base_url}kepegawaian/karyawan/detail_karyawan/${data}" class="btn btn-xs btn-info">
                                    <i class="fa fa-eye"></i>
                                </a>
                                <a href="${base_url}kepegawaian/karyawan/ubah_karyawan/${data}" class="btn btn-xs btn-warning">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <a href="#modalHapus${data}" data-toggle="modal"  data-toggle="tooltip" class="btn btn-xs btn-danger">
                                    <i class="fa fa-trash"></i>
                                </a>
                            </div>`;
        }
      }

    ],
    columnDefs: [
      {
        targets:0,
        data: "id_karyawan",
        render: function(data, type, row, meta) {
          return `<div class="text-center">
									<input name="checked[]" class="check" value="${data}" type="checkbox">
								  </div>`;
        }
      }
    ],
    order: [[3, "asc"]],
    rowId: function(a) {
      return a;
    },
      rowCallback: function(row, data, iDisplayIndex) {
      var info = this.fnPagingInfo();
      var page = info.iPage;
      var length = info.iLength;
      var index = page * length + (iDisplayIndex + 1);
      $("td:eq(1)", row).html(index);
    }
  });
table
    .buttons()
    .container()
    .appendTo("#karyawan_wrapper .col-md-6:eq(0)");

  $(".select_all").on("click", function() {
    if (this.checked) {
      $(".check").each(function() {
        this.checked = true;
        $(".select_all").prop("checked", true);
      });
    } else {
      $(".check").each(function() {
        this.checked = false;
        $(".select_all").prop("checked", false);
      });
    }
  });

  $("#karyawan tbody").on("click", "tr .check", function() {
    var check = $("#karyawan tbody tr .check").length;
    var checked = $("#karyawan tbody tr .check:checked").length;
    if (check === checked) {
      $(".select_all").prop("checked", true);
    } else {
      $(".select_all").prop("checked", false);
    }
  });
});
</script>

<script type="text/javascript">
(function() {
    'use strict';
    window.addEventListener('load', function() {
      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.getElementsByClassName('needs-validation');
      // Loop over them and prevent submission
      var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
          if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }, false);
      });
    }, false);
  })();
</script>


<!-- Load Gambar -->
<script>
	function readURL() {

    var oFReader = new FileReader();
     oFReader.readAsDataURL(document.getElementById("image").files[0]);

    oFReader.onload = function(oFREvent) {
      document.getElementById("blah").src = oFREvent.target.result;
    };
  };

</script>

<!-- FUNGSI UMUR -->
<script>
function getAge() {
	var date = document.getElementById('birthday').value;
	if(date === ""){
		alert("Please complete the required field!");
    }else{
		var today = new Date();
		var birthday = new Date(date);
		var year = 0;
		if (today.getMonth() < birthday.getMonth()) {
			year = 1;
		} else if ((today.getMonth() == birthday.getMonth()) && today.getDate() < birthday.getDate()) {
			year = 1;
		}
		var age = today.getFullYear() - birthday.getFullYear() - year;

		if(age < 0){
			age = 0;
		}
		document.getElementById('result').innerHTML = age;
	}
}
</script>

<script>
  $(function () { 
    var idkaryawan = document.getElementById('idkaryawan').value;
    var date = new Date()
    var d    = date.getDate(),
        m    = date.getMonth(),
        y    = date.getFullYear()
    $('#calendar').fullCalendar({
      header    : {
        left  : 'prev,next today',
        center: 'title',
        right : 'month'
      },
      buttonText: {
        today: 'today',
        month: 'month'
      },
      //Random default events
      events: base_url + "kepegawaian/Karyawan/datajsonabsen/"+ idkaryawan,
      editable  : true,
      droppable : true, // this allows things to be dropped onto the calendar !!!
    })
  })
</script>


<!--<script>
    $(function() {
      $('#calendar').fullCalendar({
        // now: new Date(),
        aspectRatio: 1.6,
        minTime: '07:00',
        maxTime: '23:00',
        // scrollTime: '07:00',
        header: {
          left: 'today ,next',
          center: 'title',
          right: 'agendaWeek'
        },
        defaultView: 'agendaWeek',
        default: 6,
        views: {
          timelineThreeDays: {
            type: 'timeline',
            duration: { days: 3 }
          }
        },
        resources: [
          { id: 'a', eventColor: 'green' },
          { id: 'b', eventColor: 'red' },
          { id: 'c', eventColor: 'orange' },
        ],
        events: [
                      { id: '57', resourceId: 'a', start: '2016-06-23 12:00', end: '2016-06-23 13:00', title: 'Di booking oleh : fauzi' },
                      { id: '58', resourceId: 'a', start: '2016-06-21 22:00', end: '2016-06-21 23:00', title: 'Di booking oleh : fauzi' },
                      { id: '59', resourceId: 'a', start: '2016-06-21 12:00', end: '2016-06-21 13:00', title: 'Di booking oleh : fauzi' },
                      { id: '60', resourceId: 'a', start: '2016-06-26 08:00', end: '2016-06-26 09:00', title: 'Di booking oleh : fauzi' },
                  ]
      });
    });
  </script>-->
