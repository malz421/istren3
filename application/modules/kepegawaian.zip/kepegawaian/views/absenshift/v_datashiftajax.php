<div style="/*! width: 1170px; */overflow-x: auto;white-space: nowrap;padding: 19px;">
        <div class="pull-left" style="width:30%">
            <table class="striped bordered hovered fixed">
                <thead>
                    <tr class="bg-color-grayDark">
                        <th class="fg-color-white" width="50" style="text-align:center; vertical-align: middle;">No.</th>
                        <th class="fg-color-white" width="250" style="text-align:center; vertical-align: middle;">Nama</th>
                        <th class="fg-color-white" width="40" style="text-align:center; vertical-align: middle;">Edit</th>
                    </tr>
                </thead>
                <tbody>
                        <tr>
						
                            <td width="50" style="text-align:center; vertical-align: middle;">1</td>
                            <td width="250" style="text-align:left; vertical-align: middle;">
                                AMELIZA                                <!--<a href="https://absenku.com/absenku_demo/web/index.php/daftar_shift_karyawan/edit/012" style="text-align: right" onclick="" title="Edit"><img src="https://absenku.com/absenku_demo/web/images/icon-pencil.png"  style="width:12px;height:15px;"></a>-->
                            </td>
                            <td width="40" style="text-align:center; vertical-align: middle;"><a href="https://absenku.com/absenku_demo/web/index.php/daftar_shift_karyawan/edit_data/012" onclick="" title="Edit"><img src="https://absenku.com/absenku_demo/web/images/icon-pencil.png" style="width:12px;height:15px;"></a></td>
                        </tr>
                                        </tbody>
            </table>
        </div>
        <div class="pull-right" style="width:70%;overflow-x:auto">
            <table class="striped bordered hovered fixed">
                <thead>
                    <tr class="bg-color-grayDark">
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">25/02</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">26/02</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">27/02</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">28/02</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">29/02</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">01/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">02/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">03/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">04/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">05/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">06/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">07/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">08/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">09/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">10/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">11/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">12/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">13/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">14/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">15/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">16/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">17/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">18/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">19/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">20/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">21/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">22/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">23/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">24/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">25/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">26/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">27/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">28/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">29/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">30/03</th>
                                                    <th class="fg-color-white" width="100" style="text-align:center; vertical-align: middle;">31/03</th>
                                            </tr>
                </thead>
                <tbody>
                                            <tr>
                                                                <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        LEPAS                                                                                    <a href="javascript:void(0)" onclick="delete_action('ebb71045453f38676c40deb9864f811d')" title="Delete"><img src="https://absenku.com/absenku_demo/web/images/icon-trash.png" style="width:12px;height:15px;"></a>
                                                                                </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        LEPAS                                                                                    <a href="javascript:void(0)" onclick="delete_action('0f3d014eead934bbdbacb62a01dc4831')" title="Delete"><img src="https://absenku.com/absenku_demo/web/images/icon-trash.png" style="width:12px;height:15px;"></a>
                                                                                </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="background-color: #FFAD00 ; color:white; text-align:center; 
                                        vertical-align: middle;table-layout: fixed">
                                        -                                        
                                    </td>
                                                                    <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                                        <td width="100" style="text-align:center; vertical-align: middle;table-layout: fixed">
                                        -                                                                            </td>
                                                            </tr>
                                        </tbody>
            </table>
        </div>
    <!--        <center>
            </center>-->
    </div>
