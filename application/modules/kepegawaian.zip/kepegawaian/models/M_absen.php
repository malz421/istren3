<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
  
  class M_absen extends CI_Model
  {
    public function __construct()
	 {
	  parent::__construct();
	  
	 }
	
	function tampil_karyawan($idlembaga){
		
		if($idlembaga=='all'){
			$this->db->select('*,getnamalembaga(id_lembaga) AS nama_lembaga,getnamaunitkerja(id_unit_kerja) AS unit_kerja,getnamadepartemen(id_departemen) AS nama_departemen');
			$this->db->from('karyawan');
			$this->db->where('sts_data',0);
			$this->db->order_by('nama_karyawan');
			$hsl = $this->db->get();
		}else{
			$this->db->select('*,getnamalembaga(id_lembaga) AS nama_lembaga,getnamaunitkerja(id_unit_kerja) AS unit_kerja,getnamadepartemen(id_departemen) AS nama_departemen');
			$this->db->from('karyawan');
			$this->db->where('id_lembaga',$idlembaga);
			$this->db->where('sts_data',0);
			$this->db->order_by('nama_karyawan');
			$hsl = $this->db->get();
		}
		return $hsl;
	}

	


	function detail_karyawan($id){

		
		$this->db->select('*,getnamalembaga(id_lembaga) AS namalembaga,getnamaunitkerja(1) AS unitkerja,getnamadepartemen(id_departemen) AS namadepartemen');
		$this->db->from('karyawan');
		$this->db->where('id_karyawan',$id);
		$hsl = $this->db->get();
		return $hsl;
	}

	function detail_karyawan_nip($nip){
		$this->db->select('nip_karyawan');
		$this->db->from('karyawan');
		$this->db->where('nip_karyawan',$nip);
		$hsl = $this->db->get();
		return $hsl;
	}
	
	function tambah_karyawan($data){
		$hsl=$this->db->insert('karyawan',$data);
		return $hsl;
	}

	function hapus_karyawan($id,$data){
		$this->db->where('id_karyawan',$id);
		$hsl=$this->db->update('karyawan',$data);
		return $hsl;
	}

	
	public function ubah_karyawan($kode,$data){
		$this->db->where('id_karyawan',$kode);
		$hsl=$this->db->update('karyawan',$data);
		return $hsl;
	}

	function get_nip($awalan){

		$awalan = '01'.$awalan;
	
		$q = $this->db->query("SELECT MAX(RIGHT(nip_karyawan,3)) AS kd_max FROM karyawan WHERE MID(nip_karyawan,1,8)= $awalan");
		$kd = "";
		if($q->num_rows()>0)
		{
			foreach($q->result() as $k)
			{

				$tmp = ((int)$k->kd_max)+1;
				$kd = sprintf("%03s", $tmp);
			}
		}
		else
		{
			$kd = "001";
		}
		return $awalan.$kd;
	}


	/*  KELUARGA */

	function data_keluarga($id){
		$this->db->where('id_karyawan',$id);
		$hsl = $this->db->get('karyawan_keluarga');
		return $hsl;
	}

	function detail_keluarga($idkel){

		$this->db->where('id_keluarga',$idkel);
		$hsl = $this->db->get('karyawan_keluarga');
		return $hsl;
	}

	function simpan_keluarga($data){
		$hsl=$this->db->insert('karyawan_keluarga',$data);
		return $hsl;
	}

	function ubah_keluarga($idkel,$data){
		$this->db->where('id_keluarga',$idkel);
		$hsl=$this->db->update('karyawan_keluarga',$data);
		return $hsl;
	}

	function hapus_keluarga($idkel){
		$this->db->where('id_keluarga',$idkel);
		$hsl=$this->db->delete('karyawan_keluarga');
		return $hsl;
	}

	/* END KELUARGA */



	public function rubah_tglformat($date){
		$exp = explode('-',$date);
			if(count($exp) == 3) 
			{
				$date = $exp[2].'-'.$exp[1].'-'.$exp[0];
			}
			return $date;
	}
	
	public function format_indo($date){
				$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
	
				$tahun = substr($date, 0, 4);               
				$bulan = substr($date, 5, 2);
				$tgl   = substr($date, 8, 2);
				//result = $tgl . "-" . $BulanIndo[(int)$bulan-1]. "-". $tahun;
				$result = $tgl."-".$bulan."-".$tahun;
				return($result);
		}
	
			
			public  function tgl_indo($date){
			$BulanIndo = array("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember");
	
			$tahun = substr($date, 0, 4);               
			$bulan = substr($date, 5, 2);
			$tgl   = substr($date, 8, 2);
			$result = $tgl . "-" . $BulanIndo[(int)$bulan-1]. "-". $tahun;
			//$result = $tgl."-".$bulan."-".$tahun;
			return($result);
	}


	public function tampil_combo_karyawan($idlembaga,$idunitkerja)
		{

		$karyawan = null;	
		$this->db->where('id_lembaga',$idlembaga);
		$this->db->where('id_unit_kerja',$idunitkerja);
		$this->db->order_by('nama_karyawan');
		$hsl=$this->db->get('karyawan');
		
		foreach ($hsl->result_array() as $data ){
		$karyawan.= "<option value='$data[id_karyawan]'>$data[nama_karyawan]</option>";
		}
		return $karyawan;
	}

	public function getKaryawan($idlembaga,$idunit)
	{
		
		$this->datatables->select('id_karyawan,nip_karyawan,nama_karyawan');
		$this->datatables->from('karyawan');
		if ($idlembaga !== null) {
			$this->datatables->where('id_lembaga', $idlembaga);
		}

		if ($idunit !== null) {
			$this->datatables->where('id_unit_kerja', $idunit);
		}

	
		return $this->datatables->generate();

	}

  }

?>
